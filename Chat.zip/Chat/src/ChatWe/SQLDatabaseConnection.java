package ChatWe;

// Use the JDBC driver  
import java.sql.*;  
import com.microsoft.sqlserver.jdbc.*;  
  
    @SuppressWarnings("unused")
	public class SQLDatabaseConnection {  
  
        // Connect to your database.  
        // Replace server name, username, and password with your credentials  
        public static void main(String[] args) {  
            String connectionString = "jdbc:sqlserver://localhost;databaseName=ChatSys;user=uma;password=uma";  
          
            // Declare the JDBC objects.  
            Connection connection = null;  
            Statement statement = null;   
            ResultSet resultSet = null;             
            try {  
                connection = DriverManager.getConnection(connectionString);  
                String selectSql = "SELECT TOP 10 a from dbo.t";  
                statement = connection.createStatement();  
                resultSet = statement.executeQuery(selectSql);  
  
                // Print results from select statement  
                while (resultSet.next())   
                {  
                    System.out.println(resultSet.getString(1));  
                }  
            }  
            catch (Exception e) {  
                e.printStackTrace();  
            }  
            finally {  
                // Close the connections after the data has been handled.  
                if (resultSet != null) try { resultSet.close(); } catch(Exception e) {}  
                if (statement != null) try { statement.close(); } catch(Exception e) {}  
                if (connection != null) try { connection.close(); } catch(Exception e) {}           
                if (connection != null) try { connection.close(); } catch(Exception e) {}  
            }  
        }  
    }
